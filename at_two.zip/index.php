<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
	<link href="./css/bootstrap.min.css" rel="stylesheet">
	<script src="./js/bootstrap.bundle.min.js"></script>
	<title>Assessment Two</title>
  </head>
  <body>
<!-- Grey with black text -->
    <?php
	  include_once('inc_nav.php');
    ?>
  
<!--  
<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
  <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-link" href="index.php">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="question1.php">Q 1.</a>
    </li>  
      <li class="nav-item">
      <a class="nav-link" href="question2.php">Q 2.</a>
    </li> 
    <li class="nav-item">
      <a class="nav-link" href="question3.php">Q 3.</a>
    </li>
      <li class="nav-item">
      <a class="nav-link" href="question4.php">Q 4.</a>
    </li>
  </ul>
</nav> -->
    <h1>Welcome to HTML/CSS/JS and Bootstrap 5</h1>
<div class="container p-5 my-5 bg-primary text-white">

Introduction here, </br >Your Name, </br>Your ID, </br>Assessment Details,
</div>

  </body>
</html>