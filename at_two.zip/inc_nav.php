<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
  <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-link" href="index.php">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="question1.php">Q 1.</a>
    </li>  
      <li class="nav-item">
      <a class="nav-link" href="question2.php">Q 2.</a>
    </li> 
    <li class="nav-item">
      <a class="nav-link" href="question3.php">Q 3.</a>
    </li>
      <li class="nav-item">
      <a class="nav-link" href="question4.php">Q 4.</a>
    </li>
        <li class="nav-item">
      <a class="nav-link" href="question5.php">Q 5.</a>
    </li>
        <li class="nav-item">
      <a class="nav-link" href="question6.php">Q 6.</a>
    </li>
        <li class="nav-item">
      <a class="nav-link" href="question7.php">Q 7.</a>
    </li>
        <li class="nav-item">
      <a class="nav-link" href="question8.php">Q 8.</a>
    </li>
        <li class="nav-item">
      <a class="nav-link" href="question9.php">Q 9.</a>
    </li>
  </ul>
</nav>