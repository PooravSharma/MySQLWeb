 <link rel="stylesheet" type="text/css" href="formating.css">
<ul>
<li><a href="Index.php">Home</a></li>
<li><a href="Question1.php">Question One</a></li>
<li><a href="Question2.php">Question Two</a></li>
<li><a href="Question3.php">Question Three</a></li>
<li><a href="Question4.php">Question Four</a></li>
<li><a href="Question5.php">Question Five</a></li>
<li><a href="Question6.php">Question Six</a></li>
<li><a href="Question7.php">Question Seven</a></li>
<li><a href="Question8.php">Question Eight</a></li>
<li><a href="Question9.php">Question Nine</a></li>
<li><a href="contact.php">Contact</a></li>
</ul>
