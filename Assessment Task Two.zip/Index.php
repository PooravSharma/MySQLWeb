<!DOCTYPE html>
<html>
<!-- Name: Poorav Sharma
	 ID: 30045900
	 Date: 16-08-2022
	 Task: Assessment Task Two -->
<head>
<title>Home</title>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
 <link rel="stylesheet" type="text/css" href="formating.css">
</head>

<body>
<div id= "indexBody">

<!-- List for the Navigaation bar Bar -->
	<?php
		include_once('navigation.php');  
	?>

<h1>Assessment Two: Fetching Data From A DataBase</h1>
<br>
<div class= 'container-fluid'>
<p>This multi-page website will utilise the Bootstrap, PHP, CSS and HTML to display data from a database. </p>
<p>Poorav Sharma</p>
<p>30045900</p>
</div>

</body>
</div>
</html>