<!DOCTYPE html>
<html>
<head>
<title>Contact Page</title>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
 <link rel="stylesheet" type="text/css" href="formating.css">
</head>

<div id= "contentPage">
<body>
<!-- List for the Navigaation bar Bar -->
<?php
include_once('navigation.php');
?>

<h1>Contact Page</h1>
<br>
<div id= "contactInfo">
<p>Phone: +0392093233 </p>
<p>Email: 30045900@tafe.wa.edu.au</p>
<p>Address: 130 Murdoch Dr, Murdoch WA 6150</p>
</div>
</body>
</div>
</html>